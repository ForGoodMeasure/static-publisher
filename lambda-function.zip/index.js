var aws = require('aws-sdk');
var apiGatewayRequest = require('./api-gateway-request.js');

var lambda = new aws.Lambda();

exports.handler = (event, context, callback) => {
  console.log(event);
  callback();
};
